CLUENER 细粒度命名实体识别

数据分为10个标签类别，分别为: 
地址（address），
书名（book），
公司（company），
游戏（game），
政府（goverment），
电影（movie），
姓名（name），
组织机构（organization），
职位（position），
景点（scene）

数据详细介绍、基线模型和效果测评，见 https://github.com/CLUEbenchmark/CLUENER

技术讨论或问题，请项目中提issue或PR，或发送电子邮件到 ChineseGLUE@163.com

测试集上SOTA效果见榜单：www.CLUEbenchmark.com